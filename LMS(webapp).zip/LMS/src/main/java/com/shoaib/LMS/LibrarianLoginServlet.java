package com.shoaib.LMS;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/LibrarianLoginServlet")
public class LibrarianLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String dbURL = "jdbc:mysql://localhost:3306/libmanage";
        String dbUser = "root";
        String dbPass = "shoaib";

        String username = request.getParameter("name");
        String password = request.getParameter("password");

        if (username != null && password != null) {
            Connection conn = null;
            PreparedStatement pst = null;
            ResultSet rs = null;

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(dbURL, dbUser, dbPass);

                String sql = "SELECT * FROM librarian WHERE name=? AND password=?";
                pst = conn.prepareStatement(sql);
                pst.setString(1, username);
                pst.setString(2, password);

                rs = pst.executeQuery();

                if (rs.next()) {
                    HttpSession session = request.getSession();
                    session.setAttribute("librarian", username);
                    response.sendRedirect("labrariandashboard.jsp");
                } else {
                    response.sendRedirect("librarianlogin.jsp?error=Invalid+username+or+password");
                }

            } catch (Exception e) {
                e.printStackTrace();
                response.sendRedirect("librarianlogin.jsp?error=Database+error.+Please+try+again+later.");
            } finally {
                try {
                    if (rs != null) rs.close();
                    if (pst != null) pst.close();
                    if (conn != null) conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}