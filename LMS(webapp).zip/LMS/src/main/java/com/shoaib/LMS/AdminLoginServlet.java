package com.shoaib.LMS;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/libmanage";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "shoaib";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the database
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Prepare the SQL query to check admin credentials
            String sql = "SELECT * FROM admin WHERE username = ? AND password = ?";
            pst = conn.prepareStatement(sql);
            pst.setString(1, username);
            pst.setString(2, password);

            // Execute the query
            rs = pst.executeQuery();

            if (rs.next()) {
                // If credentials are valid, create a session and redirect to the admin dashboard
                HttpSession session = request.getSession();
                session.setAttribute("admin", username);
                response.sendRedirect("admindashboard.jsp");
            } else {
                // If credentials are invalid, redirect back to the login page with an error message
                response.sendRedirect("adminlogin.jsp?error=Invalid+username+or+password");
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Redirect to the login page with a database error message
            response.sendRedirect("adminlogin.jsp?error=Database+error.+Please+try+again+later.");
        } finally {
            // Close database resources
            try {
                if (rs != null) rs.close();
                if (pst != null) pst.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}